
# Apa itu GoWarkop?

Tersedia di playstore: <br>
<a href="https://play.google.com/store/apps/details?id=io.github.adamnain.gowarkop"><img alt="Get it on Google Play" src="https://play.google.com/intl/en_us/badges/images/generic/en-play-badge.png" height=70px /></a>


GoWarkop merupakan sebuah aplikasi android yang dirancang khusus untuk Warung Indo yang terletak dijalan manisi Cibiru, Bandung . Aplikasi ini dibuat dengan tujuan agar memudahkan penikmat kopi yang berada sekitar cibiru agar melakukan pemesanan secara online (Delivery).
Berikut adalah fitur-fitur andalan GoWarkop:<br>

-Customer dapat memesan makanan,minuman,cemilan yang tersedia.<br>
-Customer dapat menentukan lokasi pengiriman<br>
-Customer dapat melihat proses pemesanan (diterima atau tidak/menunggu/waktu pengerjaan)



# Screenshot
<img src="https://github.com/adamnain/GoWarkop/blob/master/ss/1.png" width="32%">&nbsp;&nbsp;
<img src="https://github.com/adamnain/GoWarkop/blob/master/ss/2.png" width="32%">&nbsp;&nbsp;
<img src="https://github.com/adamnain/GoWarkop/blob/master/ss/3.png" width="32%">&nbsp;&nbsp;