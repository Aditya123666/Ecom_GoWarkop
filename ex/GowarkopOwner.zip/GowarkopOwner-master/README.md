
# Apa itu GoWarkop Owner?

Tersedia di playstore: <br>
<a href="https://play.google.com/store/apps/details?id=com.gowarkop.aditya123666.go_api"><img alt="Get it on Google Play" src="https://play.google.com/intl/en_us/badges/images/generic/en-play-badge.png" height=70px /></a>


GoWarkop (Owner) adalah Aplikasi android yang dirancang khusus untuk Owner GoWarkop.<br>
Berikut adalah fitur-fitur andalan GoWarkop(Owner):<br>
- Owner dapat menerima/menolak pesanan yang dilakukan customer<br>
- Owner dapat menambahkan atau menghapus daftar menu.<br>
- Owner dapat melakukan verifikasi pesanan<br>

Apa itu GoWarkop?<br>
GoWarkop merupakan sebuah aplikasi android yang dirancang khusus untuk Warung Indo yang terletak dijalan manisi Cibiru, Bandung. Aplikasi ini dibuat dengan tujuan agar memudahkan penikmat kopi yang berada sekitar cibiru agar melakukan pemesanan secara online (Delivery).



# Screenshot
<img src="https://github.com/adamnain/GowarkopOwner/blob/master/ss/2.png" width="32%">&nbsp;&nbsp;
<img src="https://github.com/adamnain/GowarkopOwner/blob/master/ss/1.png" width="32%">&nbsp;&nbsp;
<img src="https://github.com/adamnain/GowarkopOwner/blob/master/ss/3.png" width="32%">&nbsp;&nbsp;